package com.justsystems.demo;

import java.util.List;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.ActivityManager.RunningServiceInfo;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TabHost;
import android.widget.TabHost.TabSpec;

public class IMFDemoActivity extends Activity {
    ListView mProcessList;
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        TabHost tabs = (TabHost)findViewById(R.id.tabhost);
        tabs.setup();
    
        TabSpec tab1 = tabs.newTabSpec("system");
        tab1.setIndicator("System");
        tab1.setContent(R.id.contentSystem);
        tabs.addTab(tab1);
    
        TabSpec tab2 = tabs.newTabSpec("app");
        tab2.setIndicator("App");
        tab2.setContent(R.id.contentApp);
        tabs.addTab(tab2);

        TabSpec tab3 = tabs.newTabSpec("user");
        tab3.setIndicator("User");
        tab3.setContent(R.id.contentUser);
        tabs.addTab(tab3);
        tabs.setCurrentTab(0);
        
        Button button = (Button) this.findViewById(R.id.button);
        button.setText("Update");

        mProcessList = (ListView) findViewById(R.id.slist);
 
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // クリック時の処理
            	updateProcessListView();
            }
        });
    }

    void updateProcessListView() {
    	String[] sList = updateProcessInfo();
    	ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, R.layout.slist, sList);
    	mProcessList.setAdapter(adapter);
    }
    private String[] updateProcessInfo() {
 	   try {
 		   
 		   ActivityManager manager = (ActivityManager)getSystemService(ACTIVITY_SERVICE); 
 		   List<RunningServiceInfo> serviceInfoList = manager.getRunningServices(99); 
 		   int nServices = serviceInfoList.size();
 		   String[] slist = new String[nServices];
 		   int index = 0;
 		   System.out.println("Service Information... " + nServices);
 		   for (ActivityManager.RunningServiceInfo info : serviceInfoList) {
 			   StringBuffer buffer = new StringBuffer();
 			   buffer.append(info.service.getClassName());
 			   buffer.append(" (");
 			   buffer.append(info.clientCount);
 			   buffer.append(")");
 			   slist[index++] = buffer.toString();
 		   }
 		   return slist;
 		   
 	   } catch (Exception e) {
 		   e.printStackTrace();
 	   }
 	   return null;
    }

}